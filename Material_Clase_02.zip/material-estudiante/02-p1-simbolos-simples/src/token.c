#include "token.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const char *token_type_name(TokenType type) {
    switch (type) {
        case PLUS: return "PLUS";
        case MINUS: return "MINUS";
        case STAR: return "STAR";
        case SLASH: return "SLASH";
        case ASSIGN: return "ASSIGN";
        case LESS: return "LESS";
        case GREATER: return "GREATER";
        case LPAREN: return "LPAREN";
        case RPAREN: return "RPAREN";
        case LBRACE: return "LBRACE";
        case RBRACE: return "RBRACE";
        case SEMICOLON: return "SEMICOLON";
    }
    return "UNKNOWN";
}

int token_init(Token *token, TokenType type, const char *lexeme,
               size_t line, size_t column) {
    size_t length = strlen(lexeme);

    token->lexeme = malloc(length + 1);
    if (token->lexeme == NULL) {
        return 0;
    }

    memcpy(token->lexeme, lexeme, length + 1);
    token->type = type;
    token->line = line;
    token->column = column;
    return 1;
}

void token_print(const Token *token) {
    printf("%zu:%zu %s %s\n",
           token->line,
           token->column,
           token_type_name(token->type),
           token->lexeme);
}

void token_destroy(Token *token) {
    free(token->lexeme);
    token->lexeme = NULL;
}
