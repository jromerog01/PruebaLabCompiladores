# Inicio de la Práctica 1 — Símbolos simples

## Meta de los últimos 65 minutos

1. Distinguir carácter, lexema, patrón y token.
2. Revisar la separación entre `token` y `lexer`.
3. Completar `simple_token_type` en `src/lexer.c`.
4. Ejecutar el reconocimiento de símbolos simples.

## Comandos

```text
make
./minic examples/simbolos.mc
make test
./minic examples/mixto.mc
```

En `mixto.mc`, los dígitos aparecerán como elementos pendientes: reconocer enteros no forma parte del ejercicio de esta clase.

## Alcance

Esta carpeta comienza infraestructura reutilizable de P1, pero no es todavía la especificación completa. No incluye enteros, identificadores, errores léxicos ni un token de fin de archivo. La nomenclatura definitiva de esas categorías debe tomarse de la especificación de P1 cuando sea publicada.
