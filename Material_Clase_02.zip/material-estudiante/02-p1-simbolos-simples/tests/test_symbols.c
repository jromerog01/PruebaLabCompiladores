#include "lexer.h"
#include "token.h"

#include <stdio.h>
#include <string.h>

static int failures = 0;

static void check(int condition, const char *message) {
    if (!condition) {
        fprintf(stderr, "FALLO: %s\n", message);
        failures++;
    }
}

static void check_symbol(int c, TokenType expected, const char *name) {
    TokenType actual = PLUS;
    int recognized = simple_token_type(c, &actual);

    check(recognized, name);
    if (recognized) {
        check(actual == expected, name);
    }
}

int main(void) {
    Token token = {0};

    check_symbol('+', PLUS, "PLUS");
    check_symbol('-', MINUS, "MINUS");
    check_symbol('*', STAR, "STAR");
    check_symbol('/', SLASH, "SLASH");
    check_symbol('=', ASSIGN, "ASSIGN");
    check_symbol('<', LESS, "LESS");
    check_symbol('>', GREATER, "GREATER");
    check_symbol('(', LPAREN, "LPAREN");
    check_symbol(')', RPAREN, "RPAREN");
    check_symbol('{', LBRACE, "LBRACE");
    check_symbol('}', RBRACE, "RBRACE");
    check_symbol(';', SEMICOLON, "SEMICOLON");
    check(!simple_token_type('@', &(TokenType){PLUS}), "rechazar símbolo pendiente");

    check(token_init(&token, PLUS, "+", 3, 7), "crear token");
    if (token.lexeme != NULL) {
        check(strcmp(token.lexeme, "+") == 0, "copiar lexema");
        check(token.line == 3 && token.column == 7, "guardar posición");
        token_destroy(&token);
        check(token.lexeme == NULL, "liberar lexema");
    }

    if (failures == 0) {
        puts("símbolos simples: OK");
        return 0;
    }
    return 1;
}
