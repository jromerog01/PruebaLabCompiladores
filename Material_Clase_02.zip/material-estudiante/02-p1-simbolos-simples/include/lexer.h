#ifndef LEXER_H
#define LEXER_H

#include "token.h"

#include <stdio.h>

int simple_token_type(int c, TokenType *type);
int scan_simple_symbols(FILE *file);

#endif
