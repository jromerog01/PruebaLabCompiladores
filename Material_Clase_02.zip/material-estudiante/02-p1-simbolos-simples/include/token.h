#ifndef TOKEN_H
#define TOKEN_H

#include <stddef.h>

typedef enum {
    PLUS,
    MINUS,
    STAR,
    SLASH,
    ASSIGN,
    LESS,
    GREATER,
    LPAREN,
    RPAREN,
    LBRACE,
    RBRACE,
    SEMICOLON
} TokenType;

typedef struct {
    TokenType type;
    char *lexeme;
    size_t line;
    size_t column;
} Token;

const char *token_type_name(TokenType type);
int token_init(Token *token, TokenType type, const char *lexeme,
               size_t line, size_t column);
void token_print(const Token *token);
void token_destroy(Token *token);

#endif
