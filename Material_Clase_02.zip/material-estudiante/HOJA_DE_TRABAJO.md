# Hoja de trabajo — Clase 2

Esta hoja sirve para tomar notas durante la sesión. No se entrega ni se califica.

## Parte 1 — Repaso

### Buffer dinámico

- `length` representa:
- `capacity` representa:
- Se requieren `length + 2` bytes porque:
- Utilizamos un puntero temporal con `realloc` porque:

### Lectura

Completa el flujo:

```text
fopen -> __________ -> ferror -> __________
```

¿Por qué la variable que recibe `fgetc` es `int`?

## Transición

Completa:

```text
TextStats: carácter -> __________ -> contador
Lexer:     lexema   -> patrón     -> __________
```

## Parte 2 — Práctica 1

Para la entrada:

```text
{ 10 + 20; }
```

| Lexema | Posición | Categoría o estado |
|---|---|---|
| `{` | | |
| `10` | | Pendiente en esta clase |
| `+` | | |
| `20` | | Pendiente en esta clase |
| `;` | | |
| `}` | | |

### Responsabilidades

- `token.h`:
- `token.c`:
- `lexer.h`:
- `lexer.c`:
- `main.c`:

### Salida

Al terminar, escribe:

1. Algo de C que recuperaste hoy:
2. El siguiente comportamiento que deberá agregarse al lexer:
